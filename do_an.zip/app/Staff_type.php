<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Staff_type extends Model
{
      protected $table = 'staff_type';
}
