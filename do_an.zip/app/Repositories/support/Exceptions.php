<?php

namespace Nc\Support;

class RepositoryException extends \UnexpectedValueException {};