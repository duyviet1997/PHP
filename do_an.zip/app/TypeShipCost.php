<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeShipCost extends Model
{
     protected $table = 'type_ship_cost';
}
