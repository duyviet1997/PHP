<?php $__env->startSection('content'); ?>  
    <div class="row">
    
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                   
                    
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Sản phẩm liên quan</h2>
                        <?php $__currentLoopData = $group_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="thubmnail-recent">
                            <img src="<?php echo e(asset( $value->image)); ?>" class="recent-thumb" alt="">
                            <h2><a href="<?php echo e(route('productDetail',$value->id_product)); ?>"><?php echo e($value->name); ?></a></h2>
                            <div class="product-sidebar-price">
                              <?php if($value->promotion_price ==0): ?>
                                <ins><?php echo e(number_format($value->price,0,',','.')); ?></ins>
                              <?php else: ?><ins><?php echo e(number_format($value->promotion_price,0,',','.')); ?></ins> <del><?php echo e(number_format($value->price,0,',','.')); ?></del>
                              <?php endif; ?>
                                
                            </div>                             
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </div>
                    
                   
                </div>
        <div class="col-md-9">
         <div>
		  <div>
		  <div>
          <div class="modal-header">
           
          </div>
          <div class="modal-body">

            <div class="row">
                  <div class="col-md-6">
                     
                    <div class="main-img col-md-12">
                      <div class="tile" data-scale="1.6" data-image="<?php echo e(asset($product->image)); ?>"></div>
                    </div>
                    <div class="list-add">
                    <div class="list-img col-md-9">';
                    <?php for($i=0; $i < count($img); $i++): ?> 
                   <div class="img-prd row col-md-4"><img  src="<?php echo e(asset($img[$i])); ?>"alt="a"></div>
                    <?php endfor; ?>


                   </div> 
                  </div>
                  </div>
                  <div class="col-md-6">
        
                        
                <div class="tabbable"> 
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab1" data-toggle="tab">Thông tin sản phẩm</a></li>
                    <li><a href="#tab2" data-toggle="tab">Chi tiết</a></li>
                   
                  </ul>
                  <div class="tab-content">
                    <div class="tab-pane active" id="tab1">
                       <p class="id_product" id="<?php echo e($product->id_product); ?>"><?php echo e($product->name); ?></p>
                       <p>
                         <?php if($star==0): ?> 
                            <?php for($i = 0; $i < 5; $i++): ?>
                               <i class="icon-star-empty3" ></i>
                            <?php endfor; ?>
                        
                       	<?php elseif(round($star,2)< round($star) + 0.25): ?>
                       		<?php for($i = 0; $i < round($star); $i++): ?>
	                  		<i class="icon-star-full2" style="color: yellow;"></i>
	                  		<?php endfor; ?>
	                  	<?php elseif(round($star,2) >= (round($star) + 0.25) && round($star,2) < (round($star) + 0.75)): ?>
	                  		<?php for($i = 0; $i < round($star); $i++): ?>
	                  		<i class="icon-star-full2" style="color: yellow;"></i>
	                  		<?php endfor; ?>
	                  		<i class=" icon-star-half" style="color: yellow;"></i>
	                  	<?php else: ?>
	                  		<?php for($i = 0; $i < round($star)+1; $i++): ?>
	                  		<i class="icon-star-full2" style="color: yellow;"></i>
	                  		<?php endfor; ?>
                       	<?php endif; ?>
                       	
                       </p>
                       <p><?php echo e($product->price); ?> đ</p>
                       <div class="color-prd row">
                          <p>Màu sắc:</p>
                          <div class="group-img" data="<?php echo e($i=0); ?>">'
                          <?php $__currentLoopData = $list_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="col-md-2"> <img id="<?php echo e($list_color[$i]); ?>" style="width: 60px; height: 50px; margin: 0 5px;" src="<?php echo e(asset($value)); ?>" class="img-responsive" alt="<?php echo e($i++); ?>"></div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       </div>
                       </div>
                       <form>
                       <div class="size-prd row col-md-12">
                        <p>Kích thước: </p>
                        <div class="group-size"><div class="size-cont">
                        	<div class="hiden <?php echo e($arr[]=0); ?><?php echo e($i=0); ?>"></div>

                           <?php if(count($size)==0): ?>
                           <div class="out-of-stock"><span>Hết hàng</span></div>
                           <?php endif; ?>
                         <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      
                            
                             
                                
                        <div class="col-md-1"><a id="<?php echo e($value1->id_size); ?>" class="size text-center"><?php echo e($value1->size->size_name); ?></a></div>
                                      
                             

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                          
                       </div></div>
                       </div>
                        <div class="quantity buttons_added">
                          <label>Số lượng </label>
                            <input type="button" class="minus" value="-">
                            <input type="number" size="4" name="qty" class="input-text qty text" title="Qty" value="1" min="1" step="1">
                            <input type="button" class="plus" value="+">
                        </div>

                        <div class=" col-md-12">
                        <?php if(count($size)==0): ?> 
                            <div class=" btn-add-cart row col-md-7"><a class="btn border-slate btn-flat disable" data-dismiss="modal"><i class="icon-cart"></i> Thêm vào giỏ hàng</a></div>
                        
                        <?php else: ?>
                           <div class=" btn-add-cart row col-md-7"><a class="btn border-slate btn-flat " data-dismiss="modal"><i class="icon-cart"></i> Thêm vào giỏ hàng</a></div>
                        <?php endif; ?>
                        <div class=" btn-heart row col-md-5"><a  class="wishlist btn border-slate text-slate-800 btn-flat"><i class="icon-heart5"></i> </a></div>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="tab2">
                      <p>Hãng:<?php echo e($product->manufacturer->name); ?> </p>
                      <p>Mô tả:<?php echo html_entity_decode($product->description,ENT_HTML5 ); ?> </p>
                    </div>

                  </div>
              </div>
            </div>
              </div>
            
           
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


  <div class="tile" data-scale="2.4" data-image="<?php echo e(asset($product->image)); ?>"></div>

    </div>
    <div class="row col-md-12" style="margin-top: 20px;">
    <div class="col-md-2"></div>
    <div class="col-md-7">
    	<div class="page-header">
        <h1> Bình luận <small class="pull-right"><?php echo e(count($comment)); ?> bình luận</small></h1>
      </div> 
       <div class="comments-list">
       	<?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       		 <div class="media">
               <p class="pull-right"><small><?php echo e($value->created_at); ?></small></p>
                <div class="media-body">
                    
                  <h4 class="media-heading user_name"><?php echo e($value->virtual_name); ?></h4>
                  <p>Đánh giá: 
                  	<?php for($i = 0; $i < $value->star; $i++): ?>
                  		<i class="icon-star-full2" style="color: yellow;"></i>
                  	<?php endfor; ?>
                  </p>
                  <p><?php echo e($value->content); ?></p>
                  
                </div>
              </div>
       	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

       </div>
    </div>
    </div>
          
    </div>
    </div>
    </div>

   </div>
   
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>
  <script>
        $(document).ready(function(){
            $('.group-img').find('img').first().addClass('active');
        })
    </script>
     <script >
       $(document).ready(function(){
        var id_color = $('.group-img img.active').attr('id');
        var id_product = $('.group-img img.active').closest('.tab-content').find('.id_product').attr('id');
        var src =  $('.group-img img.active').attr("src");
        $.ajax({
            url: '<?php echo e(asset('/api/get_list_img')); ?>',
            method: 'POST',
            data: {
                id_product: id_product,
                id_color: id_color
            },
            success: function (html) {
               
               $('.modal-body').find('.list-img').remove('.list-img');
               $('.modal-body').find('.list-add').append(html[0]);
               $('.modal-body').find('.group-size .size-cont').remove('.size-cont');
               $('.modal-body').find('.group-size').append(html[1]);
               $('.modal-body').find('.group-size a').first().addClass('active');
                
            }
        });


    });
    </script>
  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>