<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->

<div class="modal fade" id="modal-coppy"  role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="width: 832px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Chuyển kho</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.products.warehouseTransfer')); ?>" method="POST">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" />
                   
                     <div class="row">
                          <div class="form-group col-md-3"></div>
                             <div class="form-group col-md-3">
                                <label class="">Từ kho </label>
                                <input name="id_store1" type="text" readonly="readonly" class="form-control" value="<?php echo e($id_store); ?>">

                            </div>

                            <div class="form-group col-md-3">
                                <label class="">Đến kho </label>
                                  <select name="id_store2" class="form-control select-search">
                                      <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($id_store==$sto->id): ?>
                                      <option value="<?php echo e($sto->id); ?>" <?php echo e("disabled"); ?>><?php echo $sto->name; ?></option>
                                      <?php else: ?> <option value="<?php echo e($sto->id); ?>" ><?php echo e($sto->name); ?></option>
                                      <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>

                            </div>

                             <div class="form-group col-md-3"></div>
                        </div>

                       <div class="list-add" >
                          <div class="content-add" style="height: 300px;">
                            <div class="row">
                             <div class="form-group col-md-8 ">
                                <label class="">Chọn sản phẩm</label>
                                <select name="id[]" class="form-control select2 product" >
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id_product); ?>" > <?php echo e($value->id_product); ?> - <?php echo $value->name; ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                            </div>
                           
                                   <div class="form-group list-size-color" style="height: 180px;">
                                  </div>
                            
                          </div>
                        </div> 
                                 
                        
                          <button type="button" class="btn bg-teal-400 btn-labeled btn-rounded add"><b><i class=" icon-plus3"></i></b> Thêm sản phẩm</button>
                   
                        <div class="text-right">
                            <button type="submit" id="submit-st" class="btn btn-primary legitRipple"><?php echo e(trans('base.submit')); ?> <i class="icon-arrow-right14 position-right"></i></button>
                        </div>
                </form>
            </div>

        </div>

    </div>
</div>


   <div class="page-header">
    <div class="page-header-content">
      <div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class=" text-semibold ">Sản phẩm</span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
          </div>

    </div>
    <div style="margin: 15px 0;" class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
            <ul class="breadcrumb">
                <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
                <li><a href="">Kho sản phẩm</a></li>

            </ul>
        </div>
   </div>
  <div class="breadcrumb-line breadcrumb-line-component" style="margin-bottom: 15px;">
            <ul id="navMenus" class="nav nav-pills">
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products-all'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.products.index')); ?>">Sản phẩm</a></li>   
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products-in-store')|| strpos(\Request::path(),'course'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.productsInStore.index')); ?>">Kho</a></li>  
            </ul>
    </div>

 <div class="panel panel-flat">
  
            <div class="panel-heading "> 
                <h5 class="panel-title col-md-6">Danh sách sản phẩm</h5>
                   <div class="form-group col-md-6 text-right">
                    <form class="form-show col-md-5" action="<?php echo e(route('admin.productsInStore.index')); ?>" method="GET"> 
                      <div class=" ">
                      <select name="id_store" id="load" class="form-control select-search">
                          <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($id_store==$sto->id): ?>
                          <option value="<?php echo e($sto->id); ?>" <?php echo e("selected= 'selected'"); ?>><?php echo $sto->name; ?></option>
                          <?php else: ?> <option value="<?php echo e($sto->id); ?>" ><?php echo e($sto->name); ?></option>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    </form>
                    <div class="col-md-7">
                    <a href="<?php echo e(route('admin.productsInStore.create')); ?>" id="button-export" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-plus-circle2 text-primary"></i><span>Cập nhật</span>
                    </a>
                     <a id="button-coppy" class="btn btn-link btn-float text-size-small has-text legitRipple text-slate" data-toggle="modal" data-target="#modal-coppy">                     
                        <i class=" icon-database-refresh"></i><span>Chuyển kho</span>
                    </a>

                     <a id="button-delete" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-trash icon_delete"></i><span>Xóa</span>
                    </a>
                  </div>
                  </div> 
            </div>   

            <table class="table datatable-basic">
                <thead>
                    <tr>
                    
                        <th width="5px">
                        <form action="<?php echo e(route('admin.products.toggleGroup')); ?>" method="POST" class="form-group">  
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input class="styled checked" id="checkall" type="checkbox" name="group[]" value="0">
                        </form>
                          </th>
                        <th width="5%">Mã Sản phẩm</th>
                        <th>Tên sản phẩm</th>
                       
                        <th>Số lượng tồn</th>
                        <th>Giá gốc</th>
                        <th>Giá khuyến mại</th>
                        <th>Ảnh</th>
                        <th>Tình trạng</th>

                        <th style="text-align: center">Control</th>  
                    </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                       <th><input class="check" type="checkbox" name="group[]" value="<?php echo e($value->id_product); ?>"/></th>
                       <th><?php echo $value->id_product; ?></th>                     
                       <th><a href="#"><?php echo $value->name; ?></a></th>

                      <?php $__currentLoopData = $pro_store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr_st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($id_store==$pr_st->id_store && $pr_st->id_product==$value->id_product): ?>
                         <th><?php echo $pr_st->number; ?></th>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                      
                       <th><?php echo $value->price; ?></th>
                       <th><?php echo $value->promotion_price; ?></th>
                       <th><img id="img_load" src="/<?php echo e($value->image); ?>" style="height: 50px; width: 50px;"> </th>
                       <th>
                        <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'new'])); ?>"> 
                       <?php if($value->new == 1): ?>
                          <span class="label success" style="margin: 3px auto;">New</span>
                          <?php else: ?>
                          <span class="label label-default" style="margin: 3px auto;">New</span>
                       <?php endif; ?>
                     </a>
                     <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'hot'])); ?>"> 
                        <?php if($value->hot == 1): ?>
                          <span class="label success">Hot</span>
                          <?php else: ?>
                          <span class="label label-default">Hot</span>
                       <?php endif; ?>
                     </a>
                       </th>
                     

                       <th style="text-align: center">

                           
                            <form action="<?php echo e(route('admin.productsInStore.destroyInStore',['id_product'=>$value->id_product ,'id_store'=>$id_store])); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>

                                <?php echo csrf_field(); ?>

                                <a title="Xoa" class="delete text-danger">
                                    <i class="icon-close2"></i>
                                </a>              
                            </form>
                        </th>  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
      $('#button-delete').click(function() {
        if (confirm("Bạn có muốn xóa!")){
        console.log('delete');
        $('.form-group').append('<input type="hidden" name="status" value="0">');
        $('.form-group').submit();
    }
    });
 $('.select2').select2({});


</script>
<script>
    $('#load').change(function () {
        $('.form-show').submit();
    });


    //   $(document).on('change', '.product', function () {
  
    //     var id = $(this).val();
    //     var id_store = $('input[name=id_store1]').val();
    //      $(this).addClass('changed');
    //     $.ajax({
    //         url: '/api/getNumber',
    //         method: 'POST',
    //         data: {
    //            id: id,
    //            id_store: id_store
    //         },
    //         success: function (html) {

    //            $('.content-add').each(function () {
    //                 if($(this).find('.changed').length>0){
                      
    //                    $(this).find('#number').attr('placeholder','Max : '+ html);
    //                   $(this).find('#number').attr('max',html);
    //                     $(this).find('.changed').removeClass('changed');

    //                 }
                    
    //             });
               
    //         }
    //     });
    // });


      $(document).on('change', '.product', function () {
  
        var id = $(this).val();
        var id_store = $('input[name=id_store1]').val();
        var i = $('.list-size-color').length;

            $(this).addClass('changed');
        $.ajax({
            url: '<?php echo e(asset('/api/getSizeAndColor')); ?>',
            method: 'POST',
            data: {
               id: id,
               i: i,
               id_store: id_store
            },
            success: function (html) {

              $('.content-add').each(function () {
                    if($(this).find('.changed').length>0){
                      $(this).find('.cont').remove();
                       $(this).find('.changed').removeClass('changed');
                       $(this).find('.list-size-color').append(html);
                    }
                    
                });
              
            }
        });
    });


  
// $(document).on('change', '#numberSize', function () {
//     var value = $(this).val();
//     var total = $('#totalsize').val();
      
//       $('#totalsize').attr('value',parseInt(total)+parseInt(value));
  

//     });

   



  $(document).on('click', '.add', function () {
    var id_store = $('input[name=id_store1]').val();
       $.ajax({
            url: '<?php echo e(asset('/api/addSP')); ?>',
            method: 'POST',
            data: {
                id_store: id_store
            },
            success: function (html) {
               $('.list-add').append(html);
                $('.select').select2({});
            }
        });
  

    });

       

     
   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>