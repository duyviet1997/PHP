<?php $__env->startSection('content'); ?>
<div class="container" style="min-height: 400px;">
	<div class="page-header">
   	<div class="page-header-content">
   		<div class="page-title text-center">
                <h4><i class="icon-gift icon-gift-beat" style="font-size: 25px; top: -6px;"></i> <span class=" text-semibold ">DANH SÁCH ĐƠN HÀNG</span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
          </div>

         
   	</div>
   </div>
	<div>
	<div class="col-md-3 text-left My-Account">
		<p class="item " id="Manage-My-Account"><a ><span ">Quản lý tài khoản</span></a></p>
            <ul class="item-container">
                <li id="My-profile" class="sub"><a >Thông tin cá nhân</a></li>
                <li id="Address-book" class="sub"><a >Sổ địa chỉ</a></li>
                <li id="Payment-methods" class="sub"><a >Tùy chọn thanh toán</a></li>
                <li id="Vouchers" class="sub"><a>Mã giảm giá</a></li>
            </ul>
        <p><a href=""><span>Đơn hàng của tôi</span></a></p>
         <ul class="item-container">
                <li id="My-profile" class="sub"><a >Đơn hàng hủy</a></li>
                <li id="Address-book" class="sub"><a >Đơn hàng đổi trả</a></li>
              
         </ul>
         <p><a href=""><span>Sản phẩm yêu thích</span></a></p>
	</div>
	<div class="box col-md-9">
	<?php $__currentLoopData = $myOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
	
     <div class="box-content ">
     	<div class="col-md-12">
     	<div class="col-md-4">
     	<p class="text-left" style="font-weight: bold;font-size: 16px;">Đơn hàng #<?php echo e($order->id_bill); ?></p>
     	<span style="color: #a49eab;"><i>Ngày đặt <?php echo e($order->created_at()); ?></i></span>
     	
     	</div>
     	<div class="col-md-4">
     	<p>Trạng thái : <i><?php echo e($order->status->name); ?></i> </p>
     	
     	
     	</div>
     	<div class="col-md-4 text-right">
     		<span style=" font-size: 15px;">Tổng cộng: <?php echo e(number_format($order->total_bill,0,',','.')); ?> VNĐ</span>
     	</div>
     	</div>
     	<a class="view-order btn btn-primary" href="<?php echo e(route('customer.myOrderDetail',$order->id_bill)); ?>" style="border-radius:0 ">Chi tiết</a>
     </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
	</div>
 </div>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>