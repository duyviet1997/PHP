<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('frontend/layouts/__header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>

    <body>
    	 <?php echo $__env->make('frontend/layouts/__navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	 <!-- -->
         <div class="col-md-12">
        <?php echo $__env->make('frontend/layouts/view_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	  <?php echo $__env->yieldContent('content'); ?>   
          </div>
    	 <!-- -->
    	  <?php echo $__env->make('frontend/layouts/__footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    </body>
     <?php echo $__env->make('frontend/layouts/script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('script'); ?> 
</html>  