<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->

   <div class="page-header">
   	<div class="page-header-content">
   		<div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class=" text-semibold ">Sản phẩm</span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
      </div>

   	</div>
    <div style="margin: 15px 0;" class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
            <ul class="breadcrumb">
                <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
                <li><a href="<?php echo route('admin.customer.index'); ?>">Sản phẩm</a></li>

            </ul>
        </div>
   </div>
   <div class="breadcrumb-line breadcrumb-line-component" style="margin-bottom: 15px;">
            <ul id="navMenus" class="nav nav-pills">
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.products.index')); ?>">Sản phẩm</a></li>   
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products-in-store')|| strpos(\Request::path(),'course'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.productsInStore.index')); ?>">Kho</a></li>  
            </ul>
    </div>

 <div class="panel panel-flat">
  
            <div class="panel-heading "> 
                <h5 class="panel-title col-md-8">Danh sách sản phẩm</h5>
                <div class="col-md-4 text-right">
                    <a href="<?php echo e(route('admin.products.create')); ?>" id="button-export" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-plus-circle2 text-primary"></i><span>Tạo mới</span>
                    </a>
                     <a id="button-delete" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-trash icon_delete"></i><span>Xóa</span>
                    </a>
                  </div>
            </div>   

            <table class="table datatable-basic">
                <thead>
                    <tr>
                    
                        <th width="5px">
                        <form action="<?php echo e(route('admin.products.toggleGroup')); ?>" method="POST" class="form-group">  
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input class="styled checked" id="checkall" type="checkbox" name="group[]" value="0">
                        </form>
                          </th>
                        <th>Mã Sản phẩm</th>
                        <th>Tên sản phẩm</th>
                        <th>Loại sản phẩm</th>
                        <th>Giá nhập</th>
                        <th>Giá gốc</th>
                        <th>Giá khuyến mại</th>
                        <th>Ảnh</th>
                        <th>Tình trạng</th>

                        <th style="text-align: center">Control</th>  
                    </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                       <th><input class="check" type="checkbox" name="group[]" value="<?php echo e($value->id_product); ?>"/></th>
                       <th><?php echo $value->id_product; ?></th>                     
                       <th><a href="#"><?php echo $value->name; ?></a></th>
                       <th><?php echo e($value->type->name); ?></th>
                       <th><?php echo e($value->import_price); ?></th>

                       <th><?php echo $value->price; ?></th>
                       <th><?php echo $value->promotion_price; ?></th>
                       <th><img id="img_load" src="<?php echo e(asset($value->image)); ?>" style="height: 50px; width: 50px;"> </th>
                       <th>
                        <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'new'])); ?>"> 
                       <?php if($value->new == 1): ?>
                       	  <span class="label success" style="margin: 3px auto;">New</span>
                       	  <?php else: ?>
                       	  <span class="label label-default" style="margin: 3px auto;">New</span>
                       <?php endif; ?>
                     </a>
                     <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'hot'])); ?>"> 
                        <?php if($value->hot == 1): ?>
                          <span class="label success">Hot</span>
                          <?php else: ?>
                          <span class="label label-default">Hot</span>
                       <?php endif; ?>
                     </a>
                       </th>
                     

                       <th style="text-align: center">
                            
                       
                            <a  href="<?php echo e(route('admin.products.edit',['id_product' => $value->id_product ] )); ?>" title="Chỉnh sửa" class="text-success">
                                <i class="icon-pencil"></i>
                            </a>
                           
                            <form action="<?php echo e(route('admin.products.destroy',['id_product'=>$value->id_product ])); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>

                                <?php echo csrf_field(); ?>

                                <a title="Xoa" class="delete text-danger">
                                    <i class="icon-close2"></i>
                                </a>              
                            </form>
                        </th>  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
      $('#button-delete').click(function() {
        if (confirm("Bạn có muốn xóa!")){
        console.log('delete');
        $('.form-group').append('<input type="hidden" name="status" value="0">');
        $('.form-group').submit();
    }
    });
 $('.select2').select2({});


</script>
<script>
    $('#load').change(function () {
        $('.form-show').submit();
    });



      $(document).on('change', '.product', function () {
  
        var id = $(this).val();
        var id_store = $('input[name=id_store1]').val();
        var i = $('.list-size-color').length;

            $(this).addClass('changed');
        $.ajax({
            url: '<?php echo e(asset('/api/getSizeAndColor')); ?>',
            method: 'POST',
            data: {
               id: id,
               i: i,
               id_store: id_store
            },
            success: function (html) {

              $('.content-add').each(function () {
                    if($(this).find('.changed').length>0){
                      $(this).find('.cont').remove();
                       $(this).find('.changed').removeClass('changed');
                       $(this).find('.list-size-color').append(html);
                    }
                    
                });
              
            }
        });
    });


  
// $(document).on('change', '#numberSize', function () {
//     var value = $(this).val();
//     var total = $('#totalsize').val();
      
//       $('#totalsize').attr('value',parseInt(total)+parseInt(value));
  

//     });

   



  $(document).on('click', '.add', function () {
    var id_store = $('input[name=id_store1]').val();
       $.ajax({
            url: '<?php echo e(asset('/api/addSP')); ?>',
            method: 'POST',
            data: {
                id_store: id_store
            },
            success: function (html) {
               $('.list-add').append(html);
                $('.select').select2({});
            }
        });
  

    });

       

     
   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>