<?php $__env->startSection('content'); ?>
<div class="container" style="padding: 15px 0;">
	<form>
	<div class="search-position col-md-3">
		<div class="search-price row">
			<h3 class="label-search-category">Giá</h3>
			
			<div class="form-group">
				<div class="col-md-5">
				<input class="search-price-ip form-control col-md-6" min="0" required type="number" name="min-price" placeholder="Tối thiểu">
				</div>
				<div class="col-md-5">
				<input class="search-price-ip form-control col-md-6" min="0" required type="number" name="max-price" placeholder="Tối đa">
				</div>
				<button type="button" id="price" style="width: 40px; height: 37px;"  class=" btn btn-link col-md-2"><i class="icon-play4" style="    padding-bottom: 5px; left: -6px;"></i></button>
			</div>
			
		</div>
		<div class="row text-center"><hr class="col-md-10"></div>
		<div class="search-color row " >
			<h3 class="label-search-category" style=" ">Loại</h3>
			<div class="scroll scroll1">
			<form>
			
			<div class="form-group scroll-content" >
				<?php $__currentLoopData = $type_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="checkbox"><input type="checkbox" name="id_type" value="<?php echo e($value->id); ?>" /><label><?php echo $value->name; ?></label></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			
			</form>
			</div>
		</div>
		<div class="row text-center"><hr class="col-md-10"></div>
		<div class="search-brand row ">
			<h3 class="label-search-category" style=" ">Thương hiệu</h3>
			<form>
				<div class="scroll  scroll1">
			<div class="form-group scroll-content">
				<?php $__currentLoopData = $manufacturer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="checkbox"><input type="checkbox" name="id_manufacturer" value="<?php echo e($value->id); ?>" /><label><?php echo $value->name; ?></label></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			</div>
			</form>
		</div>
		

		

	</div>
	</form>
	
	<div class="product-category col-md-9">
		<?php echo $__env->yieldContent('product'); ?>
	</div>
</div>   


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>