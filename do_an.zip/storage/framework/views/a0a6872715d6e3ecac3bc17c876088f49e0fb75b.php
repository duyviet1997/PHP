<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->




   <div class="page-header">

    <div style="margin: 15px 0;" class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
            <ul class="breadcrumb">
                <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
                <li><a href="">Báo cáo tồn kho</a></li>

            </ul>
        </div>
   </div>
   <div class="panel panel-flat">
            <div class="panel-heading">
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                        <li><a data-action="reload"></a></li>
                        
                    </ul>
                </div>
            </div>
         
        <div class="row">
          <div class="col-md-2"></div>
          <div class="col-md-8">
          <div id="app" class="chart ">
            <?php echo $chart->container(); ?>

          </div>
          </div>

        </div>
</div>
 <div class="panel panel-flat">
  
            <div class="panel-heading "> 
                <h5 class="panel-title col-md-6">Danh sách sản phẩm</h5>
                   <div class="form-group col-md-6 text-right">
                    <form class="form-show col-md-5" action="<?php echo e(route('admin.report.inventory')); ?>" method="GET"> 
                      <div class=" ">
                      <select name="id_store" id="load" class="form-control select-search">
                          <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($id_store==$sto->id): ?>
                          <option value="<?php echo e($sto->id); ?>" <?php echo e("selected= 'selected'"); ?>><?php echo $sto->name; ?></option>
                          <?php else: ?> <option value="<?php echo e($sto->id); ?>" ><?php echo e($sto->name); ?></option>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    </form>
                  </div> 
            </div>   

            <table class="table datatable-basic">
                <thead>
                    <tr>
                    
                        <th width="5%">Mã Sản phẩm</th>
                        <th>Tên sản phẩm</th>
                       
                        <th>Số lượng tồn</th>
                        <th>Số lượng đang giao</th>
                        <th>Số lượng lỗi</th>
                        <th>Ảnh</th>
                        <th>Tình trạng</th>


                    </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                       
                       <th><?php echo $value->id_product; ?></th>                     
                       <th><a href="#"><?php echo $value->name; ?></a></th>

                      <?php $__currentLoopData = $pro_store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr_st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($id_store==$pr_st->id_store && $pr_st->id_product==$value->id_product): ?>
                         <th><?php echo $pr_st->number; ?></th>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                      
                       <th><?php echo $value->number_tranf; ?></th>
                       <th><?php echo $value->number_error; ?></th>
                       <th><img id="img_load" src="/<?php echo e($value->image); ?>" style="height: 50px; width: 50px;"> </th>
                       <th>
                        <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'new'])); ?>"> 
                       <?php if($value->new == 1): ?>
                          <span class="label success" style="margin: 3px auto;">New</span>
                          <?php else: ?>
                          <span class="label label-default" style="margin: 3px auto;">New</span>
                       <?php endif; ?>
                     </a>
                     <a href="<?php echo e(route('admin.products.changeStatus',['id'=>$value->id_product,'name'=>'hot'])); ?>"> 
                        <?php if($value->hot == 1): ?>
                          <span class="label success">Hot</span>
                          <?php else: ?>
                          <span class="label label-default">Hot</span>
                       <?php endif; ?>
                     </a>
                       </th>
                     
 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script src="<?php echo e(asset('assets/js/chart/chart.min.js')); ?>"></script>
        <?php echo $chart->script(); ?>

<script>
      
 $('.select2').select2({});


</script>
<script>
    $('#load').change(function () {
        $('.form-show').submit();
    });





      $(document).on('change', '.product', function () {
  
        var id = $(this).val();
        var id_store = $('input[name=id_store1]').val();
        var i = $('.list-size-color').length;

            $(this).addClass('changed');
        $.ajax({
            url: '<?php echo e(asset('/api/getSizeAndColor')); ?>',
            method: 'POST',
            data: {
               id: id,
               i: i,
               id_store: id_store
            },
            success: function (html) {

              $('.content-add').each(function () {
                    if($(this).find('.changed').length>0){
                      $(this).find('.cont').remove();
                       $(this).find('.changed').removeClass('changed');
                       $(this).find('.list-size-color').append(html);
                    }
                    
                });
              
            }
        });
    });




  $(document).on('click', '.add', function () {
    var id_store = $('input[name=id_store1]').val();
       $.ajax({
            url: '<?php echo e(asset('/api/addSP')); ?>',
            method: 'POST',
            data: {
                id_store: id_store
            },
            success: function (html) {
               $('.list-add').append(html);
                $('.select').select2({});
            }
        });
  

    });

       

     
   
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>