<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-content">
        <div class="page-title">
            <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo e(trans('base.user')); ?></span></h4>
            <a class="heading-elements-toggle"><i class="icon-more"></i></a>
        </div>

    </div>
    <div class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
        <ul class="breadcrumb">
            <li><a href=""><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?> </a></li>
            <li><a href="<?php echo route('admin.manage'); ?>">Quản lý tài khoản hệ thống</a></li>

        </ul>
    </div>
</div>
<div class="content">
    <?php if(Session::has('success')): ?>
    <div class="alert bg-success alert-styled-left">
        <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
        <span class="text-semibold"><?php echo e(Session::get('success')); ?></span>
    </div>
    <?php endif; ?>
    <form action="<?php echo route('admin.manage.update',$admin->id); ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" />
        <div class="panel panel-body results">
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
                        <legend class="text-semibold"><i class="icon-reading position-left"></i><?php echo e(trans('base.update')); ?> <?php echo e(trans('base.user')); ?></legend>     
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label class="required"><?php echo e(trans('base.name')); ?></label>
                                <input name="name" type="text" class="form-control" value="<?php echo !is_null(old('name'))?old('name'):$admin->name; ?>">
                                <?php echo $errors->first('name', '<span class="text-danger">:message</span>'); ?>

                            </div>
                        </div>                      
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <p><input type="checkbox" id="changepassword" name="changepassword" class=""><i>Thay đổi mật khẩu</i></p>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="required"><?php echo e(trans('base.password')); ?></label>
                            <input name="password" type="password" class="form-control password" disabled>
                            <?php echo $errors->first('password', '<span class="text-danger">:message</span>'); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <label class="required"><?php echo e(trans('base.password_confirm')); ?></label>
                            <input name="password_confirmation" type="password" class="form-control password" disabled>
                            <?php echo $errors->first('password_confirmation', '<span class="text-danger">:message</span>'); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="required"><?php echo e(trans('base.role')); ?></label><br>
                        <?php if($admin->role_id ==2): ?>
                        <label class="radio-inline">
                            <input name="role_id" value="2" checked="" type="radio">Nhân viên bán hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="3" type="radio">Nhân viên quản lý kho
                        </label>
                         <label class="radio-inline">
                            <input name="role_id" value="4" type="radio">Nhân viên chăm sóc khách hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="5" type="radio">Nhân viên quản lý đăng tin.
                        </label> 
                        <?php elseif($admin->role_id ==3): ?>
                       <label class="radio-inline">
                            <input name="role_id" value="2" type="radio">Nhân viên bán hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="3" checked="" type="radio">Nhân viên quản lý kho
                        </label>
                         <label class="radio-inline">
                            <input name="role_id" value="4" type="radio">Nhân viên chăm sóc khách hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="5" type="radio">Nhân viên quản lý đăng tin.
                        </label>
                         <?php elseif($admin->role_id ==4): ?>
                         <label class="radio-inline">
                            <input name="role_id" value="2" type="radio">Nhân viên bán hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="3"  type="radio">Nhân viên quản lý kho
                        </label>
                         <label class="radio-inline">
                            <input name="role_id" value="4" checked="" type="radio">Nhân viên chăm sóc khách hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="5" type="radio">Nhân viên quản lý đăng tin.
                        </label> 
                        <?php elseif($admin->role_id ==5): ?>
                         <label class="radio-inline">
                            <input name="role_id" value="2" type="radio">Nhân viên bán hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="3"  type="radio">Nhân viên quản lý kho
                        </label>
                         <label class="radio-inline">
                            <input name="role_id" value="4" type="radio">Nhân viên chăm sóc khách hàng
                        </label>
                        <label class="radio-inline">
                            <input name="role_id" value="5" checked="" type="radio">Nhân viên quản lý đăng tin.
                        </label>
                        <?php endif; ?>
                    </div>
                </div>
                </fieldset>
            </div>
        </div>
        <div class="text-right">
            <button type="submit" class="btn btn-primary legitRipple"><?php echo e(trans('base.submit')); ?> <i class="icon-arrow-right14 position-right"></i></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    $(document).ready(function () {
        $("#changepassword").change(function () {
            if ($(this).is(":checked")) {
                $(".password").removeAttr('disabled');
            } else {
                $(".password").attr('disabled', '');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>