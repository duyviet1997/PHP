<?php $__env->startSection('content'); ?>
<div class="row">
<div class="page-header">
    <div class="page-header-content">
        <div class="page-title">
            <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Thêm sản phẩm</span></h4>
            <a class="heading-elements-toggle"><i class="icon-more"></i></a>
        </div>
    </div>
    <div class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
        <ul class="breadcrumb">
            <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
            <li><a href="###">Sản phẩm</a></li>

        </ul>


    </div>
    <div class="breadcrumb-line breadcrumb-line-component" style="margin-bottom: 15px;">
            <ul id="navMenus" class="nav nav-pills">
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products-all'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.products.index')); ?>">Sản phẩm</a></li>   
                <li style="width: 150px;" class="<?php echo e((strpos(\Request::path(),'Products-in-store')|| strpos(\Request::path(),'course'))?'active':''); ?> text-center"><a href="<?php echo e(route('admin.productsInStore.index')); ?>">Kho</a></li>  
            </ul>
    </div>

</div>
<div class="content">
    <form action="<?php echo e(route('admin.productsInStore.store')); ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" />
        <div class="panel panel-body results">
          <?php if(Session::has('mss_error')): ?>
          <div class="alert alert-danger alert-styled-left">
              <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
              <span class="text-semibold"><?php echo e(Session::get('mss_error')); ?></span>
          </div>
          <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
                        <legend class="text-semibold"><i class="icon-reading position-left"></i>Thêm sản phẩm</legend>
                        <div class="row">
                              <div class="form-group col-md-4">
                                <label class="">Kho</label>
                                <select name="id_store" class="form-control select2">
                                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store->id); ?>" <?php echo e((old('id_store')==$store->id)?'selected':''); ?>><?php echo $store->name; ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>
                        <div class="row">
                          
                            <div class="form-group select-prd col-md-7">
                                <label class="required">Sản phẩm</label>
                                <select name="id_product" class="form-control product select2">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product['id_product']); ?>"  <?php echo e((old('id_product')==$store->$product['id'])?'selected':''); ?> data-image="<?php echo e(asset($product->image)); ?>" style="padding:20px"><?php echo e($product['id_product']); ?> - - <?php echo $product['name']; ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php echo $errors->first('id_product', '<span class="text-danger">:message</span>'); ?>

                            </div>


                        </div>
                        <div class=" group col-md-8">
                          
                        </div>

                        
                    
                    </fieldset>
                </div>


            </div>

            <div class="text-right">
                <button type="submit" class="btn btn-primary legitRipple"><?php echo e(trans('base.submit')); ?> <i class="icon-arrow-right14 position-right"></i></button>
            </div>


        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
  $(".select2").select2({
    templateResult: addUserPic,
        templateSelection: addUserPic
});
  
function addUserPic (opt) {
  if (!opt.id) {
    return opt.text;
  }               
  var optimage = $(opt.element).attr('data-image'); 
  if(!optimage){
    return opt.text;
  } else {
    var $opt = $(
    '<span class="select-prd"><img src="' + optimage + '" class="userPic" /> ' + $(opt.element).text() + '</span>'
    );
    return $opt;
  }
};
</script>
    <script type="text/javascript">
        

    function previewFile() {
     var preview=document.getElementById('img_load');
     var file    = document.querySelector('input[type=file]').files[0];
     
     var reader  = new FileReader();  
     
     reader.onloadend = function () {
     preview.src = reader.result;
     
          }
          if (file) {
            reader.readAsDataURL(file);
             
          } else {
             preview.src = "";
           
          }
        }
    </script>


<script>


   $(document).on('change', '.product', function () {
        var id_product = $(this).val();
        var id_store = $('select[name=id_store]').val();
        $.ajax({
            url: '<?php echo e(asset('/api/changeProduct')); ?>',
            method: 'POST',
            data: {
               id_product: id_product,
               id_store:id_store
            },
            success: function (html) {
              $('.group').each(function () {
                    if($(this).find('.content').length>0){
                      $(this).find('.content').remove();
                      $('.group').append(html);
                    }
                    else{
                      $('.group').append(html);
                    }

                    
                });
              
            }
        });
    });
</script>
<script >
  $(document).on('change','.add_number', function(){
    var id= $(this).attr('data');
    var value= $(this).val();
    var value2=$(this).closest('.group-add-qty').find('input[data-main='+id+']').val();
    $(this).closest('.group-add-qty').find('input[data-main='+id+']').val(parseInt(value2)+parseInt(value));
  });

</script>
<?php $__env->stopSection(); ?>


  
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>