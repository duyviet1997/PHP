<div>
   Cảm ơn bạn đã đăng ký trang web của chúng tôi! 
   <p>Bạn nhận được code giảm giá với giá trị 50.000 VNĐ</p>
   <p>Mã code:  <?php echo e($code); ?></p>
</div>