<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->



   <div class="page-header">
   	<div class="page-header-content">
   		<div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class=" text-semibold ">Mã giảm giá</span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
          </div>

           <div class="heading-elements">
           	 <div class="heading-btn-group">
                   
                     <a href="<?php echo e(route('admin.discountcode.create')); ?>" id="button-export" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-plus-circle2 text-primary"></i><span>Tạo mới</span>
                    </a>
                     <a id="button-delete" class="btn btn-link btn-float text-size-small has-text legitRipple">
                        <i class="icon-trash icon_delete"></i><span>Xóa</span>
                    </a>
                </div>
           </div>
   	</div>
   </div>
   <div class="panel panel-flat">
        <div class="panel-heading">
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a data-action="collapse"></a></li>
                    <li><a data-action="reload"></a></li>
                    
                </ul>
            </div>
        </div>
      <div class="row" style="font-family: sans-serif; padding: 10px;">
        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-6">
          <p style="font-size: 16px;"><?php echo e($value->group->name); ?>: </p>
          <?php $__currentLoopData = $code_is_used; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->id_group==$element->id_group): ?>
            <p><strong>Đã sử dụng <span style="color: red;"><?php echo e($element->number_is_used); ?></span>/<?php echo e($value->number_ingroup); ?></strong></p>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

       
      </div>

</div>
 <div class="panel panel-flat">
            <div class="panel-heading">
             

                <h5 class="panel-title animated swing">Danh sách mã giảm giá</h5> 
               
            </div>   

            <table class="table datatable-basic">
                <thead>
                    <tr>
                    
                        <th width="5px">
                        <form action="<?php echo e(route('admin.discountcode.toggleGroup')); ?>" method="POST" class="form-group">  
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input class="styled checked" id="checkall" type="checkbox" name="group[]" value="0">
                        </form>
                        </th>
                        <th>Mã giảm giá</th>
                        <th>Giá trị </th>
                        <th>Trạng thái</th>
                        <th>Email nhận</th>
                        <th>Ngày tạo</th>

                        <th>Hạn sử dụng</th>
                        <th>Nhóm giảm giá</th>
                        <th style="text-align: center">Control</th>  
                    </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th><input class="check" type="checkbox" name="group[]" value="<?php echo e($value->id); ?>"/></th>
                       <th><?php echo $value->code; ?></th>
                       <?php if($value->cash!=0): ?>
                       <th><?php echo number_format($value->cash,0,',','.'); ?> đ</th>
                       <?php else: ?> <th><?php echo $value->percent; ?> %</th>
                       <?php endif; ?>
                       <?php if($value->is_used==0): ?>
                    <th><span class="text-center lable label-success" style="display: inline-block; width: 99px; padding: 2px 4px; border-radius: 15px; color: white;background:green;">Chưa kích hoạt</span></th>  
                       <?php else: ?> <th><span class="text-center lable label-danger" style="display: inline-block; padding: 2px 4px;width: 99px; border-radius: 15px;">Đã kích hoạt</span></th>  
                       <?php endif; ?>
                      
                        <th><?php echo $value->email; ?></th>
                       
                       <th><?php echo date('d-m-Y',strtotime($value->created_at)); ?></th>
                       <th><?php echo $value->expiration_date; ?></th>
                       <th><?php echo $value->group->name; ?></th>  
                       <th style="text-align: center">
                            
                           
                            <form action="<?php echo e(route('admin.discountcode.destroy',  $value->id )); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>

                                <?php echo csrf_field(); ?>

                                <a title="Xoa" class="delete text-danger">
                                    <i class="icon-close2"></i>
                                </a>              
                            </form>
                        </th>  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
      $('#button-delete').click(function() {
        if (confirm("Bạn có muốn xóa!")){
        console.log('delete');
        $('.form-group').submit();
    }
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>