

<meta charset="utf-8">
<title>HVC Shop</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Hệ thống quản lý">
<!-- Global stylesheets -->

<!-- Css -->
 <link href='<?php echo e(asset('assets/css/uikit/uikit.min.css')); ?>' rel='stylesheet' type='text/css'>
<link href='<?php echo e(asset('assets/css/uikit/uikit.css')); ?>' rel='stylesheet' type='text/css'>
<link href="<?php echo asset('assets/css/icons/icomoon/styles.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo asset('assets/css/jquery-ui.min.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo asset('assets/css/bootstrap.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo asset('assets/css/core.min.css'); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo asset('assets/css/colors.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo asset('assets/css/animate.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo asset('assets/css/components.css'); ?>" rel="stylesheet" type="text/css">




   <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.css')); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/frontend/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/frontend/style.css')); ?>">
<!-- /global stylesheets -->

<!-- Core JS files -->




<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">



<!-- /theme JS files -->
<!-- /Ckeditor files -->
<script type="text/javascript" src="<?php echo asset('ckeditor/ckeditor.js'); ?>"></script>

<script>
    var botmanWidget = {
        frameEndpoint: '/chatbot'    
    };
</script>
<script src='<?php echo e(asset('/assets/js/widget.js')); ?>'></script>

