<?php $__env->startSection('content'); ?>
 
    <div class="slider-area">
            <!-- Slider -->
            <div class="block-slider block-slider4">
                <ul class="" id="bxslider-home4">
                    <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                        <div class="col-md-8">
                            <img src="<?php echo e(asset($value->image)); ?>" alt="Slide" >
                        </div>
    
                        <div class="caption-group col-md-4"  >
                            <h2 class="caption title">
                                <span class="primary"> <?php echo e($value->name); ?></span>
                            </h2>
                            <a class="caption button-radius" href="<?php echo e(url($value->url)); ?>"><span class="icon"></span>Xem sản phẩm</a>
                        </div>
                   
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </ul>
            </div>
            <!-- ./Slider -->
    </div> <!-- End slider area -->

    
    <div class="maincontent-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="latest-product">
                        <h2 class="section-title">Sản phẩm mới nhất</h2>
                        <div class="product-carousel">
                            <?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                           
                            <div class="single-product" class="uk-width-medium-1-2 uk-flex" data-uk-scrollspy="{cls:'uk-animation-scale-up', delay: 400}">
                                <div class="product-f-image">
                                    <img src="<?php echo e(asset($value->image)); ?>" alt=""  >
                                    <div class="product-hover">
                                         <a href="<?php echo e(route('productDetail',$value->id_product)); ?>" class="add-to-cart-link"><i class="fa fa-link"></i> Xem chi tiết</a>
                                        <a data-toggle="modal" data-target="#detail-prod" id="<?php echo e($value->id_product); ?>" class="view-details-link"><i class="fa fa-shopping-cart"></i>Thêm giỏ hàng</a>
                                        <a id="check-inventory" data-id="<?php echo e($value->id_product); ?>" class="check-inventory"><i class="fa fa-link"></i> Tồn kho </a>
                                    </div>
                                </div>
                                
                                <h2 class="text-center"><a href="<?php echo e(route('productDetail',$value->id_product)); ?>"><?php echo e($value->name); ?></a></h2>
                                
                                <div class="product-carousel-price text-center">
                                     
                                    <?php if($value->promotion_price == 0): ?>
                                        <ins><?php echo e(number_format($value->price,"0",",",".")); ?></ins>
                                    <?php else: ?> 
                                       <ins><?php echo e(number_format($value->promotion_price,"0",",",".")); ?></ins>
                                        <del><?php echo e(number_format($value->price,"0",",",".")); ?></del>
                                    <?php endif; ?> 
                                </div> 
                                
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End main content area -->
        <div class="maincontent-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="latest-product">
                        <h2 class="section-title">Sản phẩm bán chạy</h2>
                        <div class="product-carousel">
                             <?php $__currentLoopData = $hot_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       
                            <div class="single-product" class="uk-width-medium-1-2 uk-flex" data-uk-scrollspy="{cls:'uk-animation-scale-up', delay: 400}">
                                <div class="product-f-image">
                                    <img src="<?php echo e(asset($value->image)); ?>" alt=""  >
                                    <div class="product-hover">
                                         <a href="<?php echo e(route('productDetail',$value->id_product)); ?>" class="add-to-cart-link"><i class="fa fa-link"></i> Xem chi tiết</a>
                                        <a data-toggle="modal" data-target="#detail-prod" id="<?php echo e($value->id_product); ?>" class="view-details-link"><i class="fa fa-shopping-cart"></i>Thêm giỏ hàng</a>
                                        
                                    </div>
                                </div>
                                
                                <h2 class="text-center"><a href="<?php echo e(route('productDetail',$value->id_product)); ?>"><?php echo e($value->name); ?></a></h2>
                                
                                <div class="product-carousel-price text-center">
                                   <?php if($value->promotion_price == 0): ?>
                                        <ins><?php echo e(number_format($value->price,"0",",",".")); ?></ins>
                                    <?php else: ?> 
                                       <ins><?php echo e(number_format($value->promotion_price,"0",",",".")); ?></ins>
                                        <del><?php echo e(number_format($value->price,"0",",",".")); ?></del>
                                    <?php endif; ?>
                                </div> 
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    
    <div class="product-widget-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="single-product-widget">
                        <h2 class="product-wid-title">Sản phẩm được đánh giá cao</h2>
                        <a href="<?php echo e(route('product_is_highly_appreciated')); ?>" class="wid-view-more">Xem thêm</a>
                        <?php $__currentLoopData = $product_star; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="single-wid-product">
                            <a href="<?php echo e(route('productDetail',$value->id_product)); ?>"><img src="<?php echo e(asset($value->product->image)); ?>" alt="" class="product-thumb"></a>
                            <h2><a><?php echo e($value->product->name); ?></a></h2>
                            <div class="product-wid-rating">
                               <?php if(round($value->ratings_average,2)< round($value->ratings_average) + 0.25): ?>
                            <?php for($i = 0; $i < round($value->ratings_average); $i++): ?>
                            <i class="icon-star-full2" style="color: yellow;"></i>
                            <?php endfor; ?>
                        <?php elseif(round($value->ratings_average,2) >= (round($value->ratings_average) + 0.25) && round($value->ratings_average,2) < (round($value->ratings_average) + 0.75)): ?>
                            <?php for($i = 0; $i < round($value->ratings_average); $i++): ?>
                            <i class="icon-star-full2" style="color: yellow;"></i>
                            <?php endfor; ?>
                            <i class=" icon-star-half" style="color: yellow;"></i>
                        <?php else: ?>
                            <?php for($i = 0; $i < round($value->ratings_average)+1; $i++): ?>
                            <i class="icon-star-full2" style="color: yellow;"></i>
                            <?php endfor; ?>
                        <?php endif; ?>
                            </div>
                            <div class="product-wid-price">
                                <?php if($value->product->promotion_price ==0): ?>
                                    <ins><?php echo e(number_format($value->product->price,0,',','.')); ?></ins>
                                <?php else: ?>
                                <ins><?php echo e(number_format($value->product->promotion_price,0,',','.')); ?></ins> <del><?php echo e($value->product->price); ?></del>
                                <?php endif; ?>
                            </div>                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                </div>
                <div class="col-md-6">
                    <div class="single-product-widget">
                        <h2 class="product-wid-title" style="">Sản phẩm giảm giá</h2>
                        <a href="<?php echo e(route('product_is_highly_appreciated')); ?>" class="wid-view-more">Xem thêm</a>
                        <?php $__currentLoopData = $discount_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="single-wid-product">
                            <a href="<?php echo e(route('productDetail',$value->id_product)); ?>"><img src="<?php echo e(asset($value->image)); ?>" alt="" class="product-thumb"></a>
                            <h2><a><?php echo e($value->name); ?></a></h2>
                            <div class="product-wid-rating">
                              
                            </div>
                            <div class="product-wid-price">
                                <?php if($value->promotion_price==0): ?>
                                    <ins><?php echo e(number_format($value->price,0,',','.')); ?></ins>
                                <?php else: ?>
                                
                                <ins><?php echo e(number_format($value->promotion_price,0,',','.')); ?></ins> <del><?php echo e(number_format($value->price,0,',','.')); ?></del>
                                <?php endif; ?>
                            </div>                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    
                </div>
            </div>
        </div>
    </div> <!-- End product widget area -->



    <?php if(Session::has('alert')): ?>
      <div class="modal fade" id="success">
      <div class="modal-dialog  modal-sm">
        <div class="modal-content bg-success" >
           
          <div class="modal-body text-center">
          	 <img style="width: 50px;height: 50px;" src="<?php echo e(asset('uploads/success.gif')); ?>">
            <span style="color: white;font-size: 20px;"><i>Đặt hàng thành công!</i></span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

   
     
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>
 <script>
        $('#success').modal('show');
       
        setTimeout(function() {
            $('#success').modal('hide');
        }, 2000);


</script>
   
   <script>
       
       $(document).on('click', '#check-inventory',function(){
        var id_product= $(this).attr('data-id');
         $.ajax({
            url: '<?php echo e(asset('/api/get_inventory')); ?>',
            method: 'POST',
            data: {
              id_product:id_product
            },
            success: function (html) {
                if (html=='out') {
                    swal('',"Sản phẩm này đã hết hàng!",  "error");
                }
                else{

                 swal("", "Còn "+html+" hàng", "success");
                }
            }
        });

       });
   </script>
   


 <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>