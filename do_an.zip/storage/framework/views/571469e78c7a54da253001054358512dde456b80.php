<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('backend/layouts/__header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>

    <body>
        <?php echo $__env->make('backend/layouts/__navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page container -->
        <div class="page-container">
            <!-- Page content -->
            <div class="page-content">
                <!-- Main sidebar -->
                <?php echo $__env->make('backend/layouts/__sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /main sidebar -->
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Content area -->
                    <div class="content row">
                        
                        <!-- Dashboard content -->
                        <?php echo $__env->yieldContent('content'); ?>   
                        <!-- /dashboard content -->
                        
                        <!-- Footer -->
                        <?php echo $__env->make('backend/layouts/__footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!-- /footer -->
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <!-- /page container -->
    </body>
    <?php echo $__env->yieldContent('script'); ?>   
</html>