<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('backend/layouts/__header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>

    <body class="login-container">
        <!-- Page container -->
        <div class="page-container">

            <!-- Page content -->
            <div class="page-content">

                <!-- Main content -->
                <div class="content-wrapper">

                    <?php echo $__env->yieldContent('content'); ?>   

                </div
            </div>
        </div>


        <!-- Footer -->
        <?php echo $__env->make('backend/layouts/__footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /footer -->

    </div>
    <?php $__env->startSection('script'); ?>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>