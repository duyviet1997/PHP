<?php $__env->startSection('content'); ?>
<!-- Advanced login -->
<form action="<?php echo route('postLogin'); ?>" method="post">
    <div class="panel panel-body login-form">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" />
        <div class="text-center">
            <div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
            <h5 class="content-group">Login to your account <small class="display-block">Your credentials</small></h5>
        </div>

        <div class="form-group has-feedback has-feedback-left">
            <input name="username" type="text" class="form-control" placeholder="Username">
            <div class="form-control-feedback">
                <i class="icon-user text-muted"></i>
            </div>
        </div>

        <div class="form-group has-feedback has-feedback-left">
            <input name="password" type="password" class="form-control" placeholder="Password">
            <div class="form-control-feedback">
                <i class="icon-lock2 text-muted"></i>
            </div>
        </div>
        <div class="form-group">
            <button type="submit" class="btn bg-pink-400 btn-block">Login <i class="icon-arrow-right14 position-right"></i></button>
        </div>
        <div class="text-center">
            <span class="txt1">
               Hoặc đăng nhập bắng
            </span>
        </div >
        <div class="group" style="height: 25px; margin: 15px auto;">
        <a href="<?php echo e(route('login.google')); ?>" class="btn-face col-md-6 text-center">
            <i class="icon-facebook2"></i>
            Facebook
        </a>

        <a href="<?php echo e(route('login.google')); ?>" class="btn-google col-md-6 text-center">
           <i class="icon-google-plus2"></i>
            Google
        </a>
        </div>
        <div class="text-center w-full p-t-10">
            <span class="txt1">
                Thành viên mới?
            </span>

            <a class="txt1 bo1 hov1" href="<?php echo e(route('getCustomerRegister')); ?>">
               đăng ký tại đây!                     
            </a>
        </div>

        <?php if(Session::has('error')): ?>
        <div class='alert alert-danger'>
            <p><?php echo Session::get('error'); ?></p>                       
        </div>
        <?php endif; ?>   

         <?php if(Session::has('register_success')): ?>
      <div class="modal fade" id="register_success">
      <div class="modal-dialog  modal-sm">
        <div class="modal-content bg-success" >
           
          <div class="modal-body text-center">
            <span style="color: white;font-size: 20px;"><i>Đăng ký thành công!</i></span>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    </div>
</form>
<!-- /advanced login -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script type="text/javascript" src="<?php echo asset('assets/backend/js/pages/login.js'); ?>"></script>
<script >
    $('#register_success').modal('show');
        $('#goToCart').modal('show');
        setTimeout(function() {
            $('#register_success').modal('hide');
        }, 2000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>