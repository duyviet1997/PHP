<?php $__env->startSection('style'); ?>
##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac##
<!--Thêm file style--> 
<style>
   /* .dataTables_filter{
        display: none;
    }
    label{
        padding: 9px!important;
    }*/
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->
<div class="row">

    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo e(trans('base.data_customer')); ?></span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
            </div>
        </div>

        <div class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
            <ul class="breadcrumb">
                <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
                <li><a href="<?php echo route('admin.customer.index'); ?>"><?php echo e(trans('base.data_customer')); ?></a></li>

            </ul>
        </div>
    </div>
    <div class="content">
        <div class="panel panel-flat">
        
          
        </div>
        <!-- Basic datatable -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h5 class="panel-title"><?php echo e(trans('base.list_customer')); ?></h5>
                <div class="heading-elements">
                    <div class="heading-btn-group">
                        <a id="button-export" class="btn btn-link btn-float text-size-small has-text legitRipple"><i class="icon-database-export text-primary"></i><span>Xuất danh sách</span></a>
                    </div>
                </div>
            </div>    

            <table class="table datatable-basic">
                <thead>
                    <tr>
                      
                        <th>
                            <form action="<?php echo e(route('admin.customer.export')); ?>" method="POST" class="form-group">  
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input class="styled" id="checkall" type="checkbox" name="group[]" value="0"/>
                            </form>
                        </th>
                        <th>Mã khách hàng</th>
                        <th>Tên khách hàng</th>
                        <th>Địa chỉ</th>
                         <th>Ngày đăng ký</th>
                        <th>SĐT</th>
                        <th>Email</th>
                        <th><?php echo e(trans('base.control')); ?></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <th><input class="check styled" type="checkbox" name="group[]" value="<?php echo e($customer->id); ?>"/></th>
                        <td><?php echo e($customer->id); ?></td>
                        <td><a href="<?php echo e(route('admin.customer.bill',$customer->id)); ?>"><?php echo e($customer->name); ?></a></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td><?php echo e($customer->created_at()); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td class="text-center">
                            <a onclick="copyToClipboard('<?php echo e($customer->phone()); ?>')" title="<?php echo e(trans('base.clipboard')); ?>">
                                <i class="icon-mobile"></i>
                            </a>
                            <form action="<?php echo route('admin.customer.destroy', $customer->id); ?>" method="POST" style="display: inline-block">
                                <?php echo method_field('DELETE'); ?>

                                <?php echo csrf_field(); ?>

                                <a title="<?php echo trans('base.delete'); ?>" class="delete text-danger">
                                    <i class="icon-close2"></i>
                                </a>              
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <!-- /basic datatable -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    $('#button-export').click(function() {
        $('.form-group').submit();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>