<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->
<div class="row">
   <div class="page-header ">
   	<div class="page-header-content">
   		<div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class=" text-semibold ">Danh sách đơn hàng</span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
          </div>

   	</div>



    <div class="breadcrumb-line breadcrumb-line-component" >
            <ul id="navMenus" class="nav nav-pills">
               
                <li class="<?php echo e((strpos(\Request::path(),'billAll'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index'); ?>">Tất cả</a></li>   
                <li class="<?php echo e((strpos(\Request::path(),'filter-1'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index1'); ?>"><i class="badge bg-warning-400"><?php echo e($count); ?></i>Mới</a></li>  
                 <li class="<?php echo e((strpos(\Request::path(),'filter-2'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index2'); ?>">Đang xử lý</a></li>   
                <li class="<?php echo e((strpos(\Request::path(),'filter-3'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index3'); ?>">Đang giao hàng</a></li>  
                <li class="<?php echo e((strpos(\Request::path(),'filter-4'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index4'); ?>">hoàn thành</a></li> 
                
                <li class="<?php echo e((strpos(\Request::path(),'filter-5'))?'active':''); ?>"><a href="<?php echo route('admin.bill.index5'); ?>">Đơn hàng hủy</a></li> 
            </ul>
      </div>
   </div> 
   <div class="content">
 <div class="panel panel-flat" style="background: ">
            <div class="panel-heading">
             

                <h5 class="panel-title ">Danh sách đơn đặt hàng</h5> 
            </div>   

            <table class="table datatable-basic">
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Khách hàng</th>
                        <th>Sử dụng mã giảm giá</th>
                        <th>Chi phí ship</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th>Ngày đặt</th>

                        <th style="text-align: center">Control</th>  
                    </tr>
                </thead>

                <tbody>
                 <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       <th><?php echo $value->id_bill; ?></th>                     
                       <th><a href="#"><?php echo $value->user->name; ?></a></th>
                       <th><?php echo $value->id_code; ?></th>
                       <th><?php echo $value->ship_cost; ?></th>
                       <th><?php echo $value->total_bill; ?></th>
                       <th><?php echo $value->status_order; ?></th>
                       <th><?php echo $value->date_order; ?></th>
                       
                       <th style="text-align: center">

                        <a  href="<?php echo e(route('admin.bill.detail',$value->id_bill )); ?>" style="margin-bottom: 3px;" title="" class="label label-primary">
                                <i class="icon-enter2">Chi tiết</i>
                            </a>
                           
                            <form action="<?php echo e(route('admin.bill.cancel',  $value->id_bill )); ?>" method="GET">
                               
                                <a title="Xoa" class="delete label label-danger" style="    width: 80px;">
                                    <i class="icon-close2"> Hủy</i>
                                </a>              
                            </form>
                        </th>  
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
      $('#button-delete').click(function() {
        if (confirm("Bạn có hủy đơn hàng!")){
        console.log('delete');
        $('.form-group').append('<input type="hidden" name="status" value="0">');
        $('.form-group').submit();
    }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>