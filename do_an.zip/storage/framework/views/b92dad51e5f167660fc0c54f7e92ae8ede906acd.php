<!doctype html>
<html>
<head>
    <title>Hỗ trợ khách hàng</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/chat.css')); ?>">
</head>
<body>
<script id="botmanWidget" src='<?php echo e(asset('assets/js/chat.js')); ?>'></script>
</body>
</html>
