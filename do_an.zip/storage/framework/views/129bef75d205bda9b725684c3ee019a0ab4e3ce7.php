<?php $__env->startSection('content'); ?>
<!-- Dashboard content -->
<div class="row">

    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo e(trans('base.user')); ?></span></h4>
                <a class="heading-elements-toggle"><i class="icon-more"></i></a>
            </div>
            <div class="heading-elements">
                <div class="heading-btn-group">                 
                    <a href="<?php echo route('admin.manage.create'); ?>" id="button-export" class="btn btn-link btn-float text-size-small has-text legitRipple"><i class="icon-plus-circle2 text-primary"></i><span><?php echo e(trans('base.add_user')); ?></span></a>                 
                </div>
            </div>   
        </div>

        <div class="breadcrumb-line breadcrumb-line-component"><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
            <ul class="breadcrumb">
                <li><a href="<?php echo route('admin.index'); ?>"><i class="icon-home2 position-left"></i><?php echo e(trans('base.system')); ?></a></li>
                <li><a><?php echo e(trans('base.user')); ?></a></li>
            </ul>
        </div>
    </div> 
    <div class="content">
<!--        <?php if(Session::has('success')): ?>
        <div class="alert bg-success alert-styled-left">
            <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
            <span class="text-semibold"><?php echo e(Session::get('success')); ?></span>
        </div>
        <?php endif; ?>-->
        <!-- Basic datatable -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h5 class="panel-title"><?php echo e(trans('base.list_user')); ?></h5>            
            </div>   
            <table class="table datatable-basic">
                <thead>
                    <tr>
                        <th></th>
                        <th><?php echo e(trans('base.name')); ?></th>               
                        <th><?php echo e(trans('base.role')); ?></th>
                        <th><?php echo e(trans('base.status')); ?></th>        
                        <th class="text-center"><?php echo e(trans('base.control')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                        <td><?php echo e($key+1); ?></td> 
                        <td><?php echo e($admin->name); ?></td>
                        <td><?php echo e($admin->role->name); ?>

                        <td class="text-center">
                            <a href="<?php echo e(route('admin.user.toggle',$admin->id)); ?>">
                                <?php if($admin->status==1): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-default">Disabled</span>
                                <?php endif; ?>
                            </a>
                        </td>
                        <td style="text-align: center" > 
                            <a  href="<?php echo route('admin.manage.edit',$admin->id); ?>" title="<?php echo e(trans('base.update')); ?>" class="text-success">
                                <button type="button" class="btn text-success btn-flat btn-icon">
                                    <i class="icon-pencil"></i>
                                </button>
                            </a>
                            <button type="button" class="btn text-warning-600 btn-flat btn-icon">
                                <form action="<?php echo route('admin.manage.delete',$admin->id); ?>" method="POST" class="del">
                                    <?php echo csrf_field(); ?>

                                    <a title="<?php echo trans('backend/base.btn_delete'); ?>" class="delete text-danger">
                                        <i class="icon-close2"></i>
                                    </a>              
                                </form>
                            </button>
                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>

        </div>
        <!-- /basic datatable -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>