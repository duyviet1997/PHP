/* ------------------------------------------------------------------------------
*
*  # Learning page kit
*
*  Specific JS code additions for learning html page kit
*
*  Version: 1.0
*  Latest update: Oct 10, 2016
*
* ---------------------------------------------------------------------------- */

$(function() {

    // Checkboxes/radios (Uniform)
    // ------------------------------

    $(".styled, .multiselect-container input").uniform({
        radioClass: 'choice'
    });
    
});
