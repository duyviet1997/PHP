<?php

use Illuminate\Database\Seeder;

class BillDetailSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
       //  DB::table('bill_detail')->insert([
            
       //      'id_bill' => '1',
       //      'id_product'=>'SP003',
       //      'price' => '200000',
       //      'number'=>'5',
       //      'total'=>'1000000'
       //  ]);
       //   DB::table('bill_detail')->insert([
            
       //     'id_bill' => '1',
       //      'id_product'=>'SP002',
       //      'price' => '200000',
       //      'number'=>'1',
       //      'total'=>'200000'
       //  ]);
       //    DB::table('bill_detail')->insert([
            
       //     'id_bill' => '2',
       //      'id_product'=>'SP002',
       //      'price' => '200000',
       //      'number'=>'1',
       //      'total'=>'200000'
       //  ]);
       // DB::table('bill_detail')->insert([
            
       //     'id_bill' => '2',
       //      'id_product'=>'SP003',
       //      'price' => '200000',
       //      'number'=>'1',
       //      'total'=>'200000'
       //  ]);
       
    }
     

}
