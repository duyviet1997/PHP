
<?php

use Illuminate\Database\Seeder;

class ColorSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
       //  DB::table('color')->insert([
            
       //      'color_name' => 'Trắng'
           
       //  ]);
       //   DB::table('color')->insert([
            
       //      'color_name' => 'Đen'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Nhiều màu'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Xanh da trời'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Xám'
           
       //  ]);
        
       //       DB::table('color')->insert([
            
       //      'color_name' => 'Hồng'
           
       //  ]);
       //   DB::table('color')->insert([
            
       //      'color_name' => 'Đỏ'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Vàng'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Trung tính'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Cam'
           
       //  ]);
       //      DB::table('color')->insert([
            
       //      'color_name' => 'Màu kaki'
           
       //  ]);
       //   DB::table('color')->insert([
            
       //      'color_name' => 'Nâu'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Màu cà phê'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Bạc'
           
       //  ]);
       // DB::table('color')->insert([
            
       //      'color_name' => 'Hường'
           
       //  ]);
    }
     

}
