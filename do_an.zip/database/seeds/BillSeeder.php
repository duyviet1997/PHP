<?php

use Illuminate\Database\Seeder;

class BillSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
       //  DB::table('bill')->insert([
            
       //      'id_user' => '5',
       //      'total_bill'=>'1200000',
       //      'status_order' => '4',
       //      'id_shipper'=>'1',
       //      'ship_cost'=>'0',
       //      'date_order'=>'2018-9-22',
       //      'date_finish' =>'2018-9-25'
       //  ]);
       //   DB::table('bill')->insert([
            
       //      'id_user' => '5',
       //      'total_bill'=>'1500000',
       //      'status_order' => '4',
       //       'id_shipper'=>'1',
       //       'ship_cost'=>'15000',
       //      'date_order'=>'2018-9-1',
       //      'date_finish' =>'2018-9-4'
       //  ]);
       //    DB::table('bill')->insert([
            
       //      'id_user' => '6',
       //      'total_bill'=>'1200000',
       //      'status_order' => '4',
       //       'id_shipper'=>'2',
       //       'ship_cost'=>'15000',
       //     'date_order'=>'2018-9-5',
       //      'date_finish' =>'2018-9-10'
       //  ]);
       // DB::table('bill')->insert([
            
       //      'id_user' => '6',
       //      'total_bill'=>'900000',
       //      'status_order' => '4',
       //       'id_shipper'=>'2',
       //      'ship_cost'=>'15000',
       //     'date_order'=>'2018-9-1',
       //      'date_finish' =>'2018-9-4'
       //  ]);
       //  DB::table('bill')->insert([
            
       //      'id_user' => '7',
       //      'total_bill'=>'900000',
       //      'status_order' => '1',
       //       'id_shipper'=>'2',
       //      'ship_cost'=>'15000',
       //     'date_order'=>'2018-9-1',
       //      'date_finish' =>'2018-9-4'
       //  ]);
       //   DB::table('bill')->insert([
            
       //      'id_user' => '6',
       //      'total_bill'=>'900000',
       //      'status_order' => '1',
       //       'id_shipper'=>'2',
       //      'ship_cost'=>'15000',
       //     'date_order'=>'2018-9-1',
       //      'date_finish' =>'2018-9-4'
       //  ]);
       
    }
     

}
